#include "stm32f4xx.h"
#include "./usart/bsp_debug_usart.h"
#include "./led/bsp_led.h"
int main(void)
{

  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
  LED_GPIO_Config();
  Debug_USART1_Config();
  Debug_USART2_Config();
  Debug_USART3_Config();
  Debug_USART4_Config();



  while(1)
    {
    }
}



/*********************************************END OF FILE**********************/

