
#include "stm32f4xx.h"
#include "./led/bsp_led.h"
#include "./systick/bsp_SysTick.h"
#include "./uart/uart.h"
#define PX4_usleep(x)			Delay_us(x)
#define PX4_msleep(x)          	PX4_usleep(x*1000)
#define PX4_sleep(x)            PX4_msleep(x*1000)
int main(void)
{
    LED_GPIO_Config();
    SysTick_Init();
    USART1_Config();
    USART2_Config();
    USART3_Config();
    USART4_Config();
    USART5_Config();
    USART6_Config();
    unsigned char DEBUG_USART1_Len = 0x00;
    unsigned char DEBUG_USART2_Len = 0x00;
    unsigned char DEBUG_USART3_Len = 0x00;
    unsigned char DEBUG_USART4_Len = 0x00;
    unsigned char DEBUG_USART5_Len = 0x00;
    unsigned char DEBUG_USART6_Len = 0x00;
    unsigned char CRC_GRAPHICS_BOADR = 0x00;
    unsigned char CRC_SPRUCE = 0x00;
    unsigned char SPRUCE_Header = 0xAA;
    unsigned char SPRUCE_Buffer[1024] = {0x00};
    unsigned char i = 0x00;
    unsigned char RX_SPRUCE_BUFF[1024] = {0};
    unsigned char USART3_Lock = 1;
    //�ӷɿط���������չ���ȡ������̨�����ݣ���������У��λ
    unsigned char k, len;
    unsigned char t = 0;
    unsigned char crc = 0x00;
    int j = 1;

    while(1)
    {
        //ͼ��忨->������չ��->�ɿ�
        if(get_usart1RxFlag == 1)
        {
            //USART3����
            USART3_Lock = 0;
            //���ձ�־λ����
            get_usart1RxFlag = 0;
            //��ȡ����֡����
            DEBUG_USART1_Len = get_usart1ReceiveBuff[2];

            //����У��λ����֤�����ڴ�������Ƿ񶪰�
            for(i = 0; i < (DEBUG_USART1_Len - 2); i++)
            {
                CRC_GRAPHICS_BOADR += get_usart1ReceiveBuff[i];
            }

            //������У���޴����������ݣ�����֮����������У��λ
            if(get_usart1ReceiveBuff[DEBUG_USART1_Len - 2] == CRC_GRAPHICS_BOADR)
            {
                GPIO_ToggleBits(GPIOE, GPIO_Pin_7);

                for(i = 0; i < (DEBUG_USART1_Len); i++)
                {
                    Usart_SendHalfHalfWord(USART2, get_usart1ReceiveBuff[i]);
                }

                CRC_GRAPHICS_BOADR = 0x00;
            }

            //������У����������������ݲ���������У��λ,Ϊ��һ�μ���У��λ��׼��
            CRC_GRAPHICS_BOADR = 0x00;
            USART3_Lock = 1; //USART3���ͷ�
            get_usart1Len = 0;
            memset(get_usart1ReceiveBuff, 0x00, sizeof(get_usart1ReceiveBuff));
        }

        //�ɿ�->������չ��->��̨
        if(get_usart2RxFlag == 1)
        {
            //��ȡ֡���ݳ���
            DEBUG_USART2_Len = get_usart2ReceiveBuff[2];
            //���ܱ�־λ����
            get_usart2RxFlag = 0;
            //У��λ����
            CRC_SPRUCE = 0x00;
            //���͸���̨���ݵ�У�������������
            t = 0;
            crc = 0x00;
            //���͸���̨�����������㣬���ⷢ�����ݳ���
            memset(SPRUCE_Buffer, 0x00, sizeof(SPRUCE_Buffer));

            //����У��λ
            for(i = 0; i < (DEBUG_USART2_Len - 2); i++)
            {
                CRC_SPRUCE += get_usart2ReceiveBuff[i];
            }

            //�����޴���
            if(get_usart2ReceiveBuff[DEBUG_USART2_Len - 2] == CRC_SPRUCE)
            {
                GPIO_ToggleBits(GPIOE, GPIO_Pin_7);
                CRC_SPRUCE = 0x00;
                SPRUCE_Buffer[0] = SPRUCE_Header;
                j = 1;

                for(i = 5; i < DEBUG_USART2_Len - 2; i++)
                {
                    SPRUCE_Buffer[j] = get_usart2ReceiveBuff[i];
                    j++;
                }

                len = SPRUCE_Buffer[1] - 1;

                while(len--)
                {
                    crc ^= SPRUCE_Buffer[t++];

                    for(k = 8; k > 0; --k)
                    {
                        if(crc & 0x80)
                        {
                            crc = (crc << 1) ^ 0xD5;
                        }
                        else
                        {
                            crc = (crc << 1);
                        }
                    }
                }

                SPRUCE_Buffer[j] = crc;

                for(i = 0; i < SPRUCE_Buffer[1]; i++)
                {
                    Usart_SendHalfHalfWord(USART3, SPRUCE_Buffer[i]);
                }
            }

            get_usart2Len = 0;
            memset(SPRUCE_Buffer, 0x00, sizeof(SPRUCE_Buffer));
            memset(get_usart2ReceiveBuff, 0x00, sizeof(get_usart2ReceiveBuff));
        }

        //��̨->������չ��->�ɿ�
        if(get_usart3RxFlag == 1)
        {
            //���ܱ�־λ����
            get_usart3RxFlag = 0;
            //������̨�������㣬������ִ������ݴ���
            memset(RX_SPRUCE_BUFF, 0x00, sizeof(RX_SPRUCE_BUFF));

            if(USART3_Lock)
            {

                GPIO_ToggleBits(GPIOE, GPIO_Pin_7);
                DEBUG_USART3_Len = get_usart3ReceiveBuff[1];
                RX_SPRUCE_BUFF[0] = 0xA9;
                RX_SPRUCE_BUFF[1] = 0x9A;
                RX_SPRUCE_BUFF[2] = 0x05 + DEBUG_USART3_Len;
                RX_SPRUCE_BUFF[3] = 0x00;
                RX_SPRUCE_BUFF[4] = 0x20;
                j = 5;

                for(k = 1; k < DEBUG_USART3_Len - 1; k++)
                {
                    RX_SPRUCE_BUFF[j] = get_usart3ReceiveBuff[k];
                    j++;
                }

                RX_SPRUCE_BUFF[j] = 0x00;

                for(k = 0; k < RX_SPRUCE_BUFF[2] - 2; k++)
                {
                    RX_SPRUCE_BUFF[j] += RX_SPRUCE_BUFF[k];
                }

                RX_SPRUCE_BUFF[j + 1] = 0xAA;

                for(k = 0; k < RX_SPRUCE_BUFF[2]; k++)
                {
                    Usart_SendHalfHalfWord(USART2, RX_SPRUCE_BUFF[k]);
                }
            }

            get_usart3Len = 0;
            memset(get_usart3ReceiveBuff, 0x00, sizeof(get_usart3ReceiveBuff));
        }

        if(get_usart4RxFlag == 1)
        {
            DEBUG_USART4_Len = get_usart4ReceiveBuff[1];

            for(i = 0; i < DEBUG_USART4_Len; i++)
            {
                Usart_SendHalfHalfWord(DEBUG_USART4, get_usart4ReceiveBuff[i]);
            }

            get_usart4RxFlag = 0;
            get_usart4Len = 0;
            memset(get_usart4ReceiveBuff, 0x00, sizeof(get_usart4ReceiveBuff));
            GPIO_ToggleBits(GPIOE, GPIO_Pin_7);
        }

        if(get_usart5RxFlag == 1)
        {
            DEBUG_USART5_Len = get_usart5ReceiveBuff[1];

            for(i = 0; i < DEBUG_USART5_Len; i++)
            {
                Usart_SendHalfHalfWord(DEBUG_USART5, get_usart5ReceiveBuff[i]);
            }

            get_usart5RxFlag = 0;
            get_usart5Len = 0;
            memset(get_usart5ReceiveBuff, 0x00, sizeof(get_usart5ReceiveBuff));
            GPIO_ToggleBits(GPIOE, GPIO_Pin_7);
        }

        if(get_usart6RxFlag == 1)
        {
            DEBUG_USART6_Len = get_usart6ReceiveBuff[1];

            for(i = 0; i < DEBUG_USART6_Len; i++)
            {
                Usart_SendHalfHalfWord(DEBUG_USART6, get_usart6ReceiveBuff[i]);
            }

            get_usart6RxFlag = 0;
            get_usart6Len = 0;
            memset(get_usart6ReceiveBuff, 0x00, sizeof(get_usart6ReceiveBuff));
            GPIO_ToggleBits(GPIOE, GPIO_Pin_7);
        }
    }
}




/*********************************************END OF FILE**********************/



