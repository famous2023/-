#ifndef __LED_H
#define __LED_H

#include "stm32f4xx.h"

//���Ŷ���
/*******************************************************/
//B ��ɫ��
#define LED_PIN                  GPIO_Pin_7
#define LED_GPIO_PORT            GPIOE
#define LED_GPIO_CLK             RCC_AHB1Periph_GPIOE


void LED_GPIO_Config(void);

#endif /* __LED_H */
