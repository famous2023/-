#include "./crc/crc.h"

unsigned char CRC_GRAPHICS_BOADR_Calculation()